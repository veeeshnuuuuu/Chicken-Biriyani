from django.db import models

from django.contrib.auth.models import AbstractUser
class Register(AbstractUser):
    usertype=models.CharField(max_length=100,null=True,default='admin')
    image=models.FileField(upload_to='profile_image',null=True)
    phone=models.PositiveIntegerField(default=0,null=True)


class Expense(models.Model):
    title=models.CharField(max_length=100,null=True,default='admin')
    description=models.CharField(max_length=1000,null=True,default='admin')
    amount=models.PositiveIntegerField(default=0,null=True)
    date=models.DateField(auto_now_add=True)