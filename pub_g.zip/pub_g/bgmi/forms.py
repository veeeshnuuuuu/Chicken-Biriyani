from django import forms
from .models import *

class RegisterForm(forms.ModelForm):
    class Meta:
        model=Register
        fields=['username','email','password','image','phone']

class LoginForm(forms.ModelForm):
    class Meta:
        model=Register
        fields=['username','password']


class ExpenseForm(forms.ModelForm):
    class Meta:
        model=Expense
        fields=['title','description','amount']

