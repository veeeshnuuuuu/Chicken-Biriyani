from django import forms
from .models import *

class RegisterForm(forms.modelform):
    class Meta:
        model=Register
        fields=['username','email','password','image','phone_number']